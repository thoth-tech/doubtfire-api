This is an exam created by the Numbas system.
Copyright in the exam content resides with the exam author.

Numbas is:
Copyright 2011-17 Newcastle University

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

The icons are from Font Awesome by Dave Gandy - http://fortawesome.github.com/Font-Awesome

The following libraries are used:
    jQuery (http://jquery.com)
    jQuery-UI (http://jqueryui.com/)
    MathJax (http://mathjax.org)
    jQuery.xslTransform & jQuery.debug (http://jquery.glyphix.com/)
    Sarissa (http://sarissa.sf.net)
    knockout.js (http://knockoutjs.com/)
    i18next (https://www.i18next.com)
    seedrandom.js (http://davidbau.com/encode/seedrandom.js)
    es6-promise (https://github.com/stefanpenner/es6-promise)
    parsel (https://parsel.verou.me)
